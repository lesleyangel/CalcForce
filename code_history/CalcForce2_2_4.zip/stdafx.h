/* stdafx.h */
#pragma once
#include <algorithm>
#include <cctype>
#include <cmath>
#include <ctime>
#include <direct.h>
#include <fstream>
#include <io.h>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <omp.h>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <Windows.h>
#include <WinBase.h>
using namespace std;

#pragma warning(disable:4018)
#pragma warning(disable:4251)
static int t1;
static int t2;
static int setw_value = 20;
#define pi 3.1415926
#define mat4D vector<vector<vector<vector<double>>>> 
            // [ALT] [MACH][ALPHA] [BETA][Coeffifient]
/* end of stdafx.h */